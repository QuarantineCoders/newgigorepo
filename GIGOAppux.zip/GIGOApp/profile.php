<?php
include "config.php";
$id=$_POST['id'];
$sql =" select customer.Name,customer.cus_id,customer.House_no,customer.contact_no, user.email , address.street ,address.city from customer inner join user on customer.cus_id=user.id inner join address on customer.street_id=address.street_id where customer.cus_id='$id';";
$result =array();
$res=$con->query($sql);
//print_r($res);
if ($res->num_rows>0)
{
  while ($row=$res->fetch_assoc()){
    $result[]=$row;
  }
}
echo json_encode($result);
 ?>
