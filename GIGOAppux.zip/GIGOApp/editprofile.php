<?php
include "config.php";

$street=$_POST['street'];
$city=$_POST['city'];
$houseno=$_POST['house_no'];
$id=$_POST['id'];
$name=$_POST['name'];


if($name != "" && $city!=""){
$sql="update customer set Name='$name' , House_no='$houseno', street_id=(select street_id from address where street='$street' and city='$city')  where cus_id='$id' ";
if($con->query($sql)){
  echo "true";
}else {
  echo "false";
}
}
?>
