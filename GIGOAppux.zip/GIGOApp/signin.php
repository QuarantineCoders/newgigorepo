<?php
include "config.php";
$email=$_POST['email'];
$password=$_POST['password'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$street=$_POST['street'];
$city=$_POST['city'];
$houseno=$_POST['house_no'];
$contact=$_POST['contact_no'];
$name= $firstname." ".$lastname;

$sql1="insert into customer (Name,House_no,street_id,contact_no) values ('$name','$houseno',(select street_id from address where street='$street' and city='$city'),'$contact')";
$sql2="insert into user (email,password,id) values ('$email','$password',(select cus_id from customer where name='$name' ))";
$sql3="insert into details (id,total,decomposable,nondecomposable,capablecompost,ecobrick,amount) values ((select cus_id from customer where name='$name' ),'0','0','0','0','0','0')";
if($con->query($sql1)){
  echo "true";
}else {
  echo "false";
}
if($con->query($sql2)){
  echo "true";
}else {
  echo "false";
}
if($con->query($sql3)){
  echo "true";
}else {
  echo "false";
}

?>
