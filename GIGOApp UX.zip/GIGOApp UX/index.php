<?php
include "config.php";
$id=$_POST['id'];
$sql ="select * from details where id='$id'";
$result =array();
$res=$con->query($sql);
//print_r($res);
if ($res->num_rows>0)
{
  while ($row=$res->fetch_assoc()){
    $result[]=$row;
  }
}
echo json_encode($result);
 ?>
