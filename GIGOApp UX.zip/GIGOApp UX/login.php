<?php
include "config.php";
$password=$_POST['password'];
$email=$_POST['email'];
$sql ="select * from user  where password='$password' and email='$email'";
$result =array();
$res=$con->query($sql);
//print_r($res);
if ($res->num_rows>0)
{
  while ($row=$res->fetch_assoc()){
    $result[]=$row;
  }
}
echo json_encode($result);
 ?>
